TraceProof ProofBundle v0.3
Independent verification: python -m traceproof.cli verify <bundle.zip>
Verify against a separately trusted public key to authenticate the signing key.
A valid archive alone does NOT prove the underlying content is true or human-created.
All timestamps are based on a local clock, without external notarization.
